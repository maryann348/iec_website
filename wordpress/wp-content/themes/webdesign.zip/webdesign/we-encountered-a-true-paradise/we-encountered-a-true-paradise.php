<?php
/**
/* Template Name: test
 *
 * Displays Only test template
 *
 * @package WordPress
 * @subpackage webdesign
 * @since webdesign 1.0
 */
 get_header(); ?>

<div id="ajax-content-wrap">
<div class="container-wrap">
<div class="container main-content">
<div class="row">
<div class="wpb_row vc_row-fluid vc_row top-level full-width-content vc_row-o-equal-height vc_row-flex vc_row-o-content-top" data-column-margin="default" data-midnight="dark" id="fws_616549184c67e" style="padding-top: 0px; padding-bottom: 0px;">
<div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="false">
<div class="inner-wrap">
<div class="row-bg" style=""></div>
</div>
</div>
<div class="row_col_wrap_12 col span_12 dark left">
<div class="vc_col-sm-12 wpb_column column_container vc_column_container col no-extra-padding" data-animation="" data-bg-color="" data-bg-opacity="1" data-delay="0" data-has-bg-color="false" data-padding-pos="all">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="nectar-recent-posts-single_featured parallax_section" data-animate-in-effect="zoom-out" data-bg-overlay="diagonal_gradient" data-height="600" data-padding="12%" data-remove-post-author="" data-remove-post-comment-number="" data-remove-post-date="" data-remove-post-nectar-love="" id="rps_6165491850b7c">
<div class="nectar-recent-post-slide no-bg-img post-ref-0">
<div class="row-bg using-image" data-parallax-speed="fast">
<div class="nectar-recent-post-bg" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2014/07/rob-bates-306647-1.jpg);"></div>
</div>
<div class="recent-post-container container">
<div class="inner-wrap">
<div class="grav-wrap"><a href="author/nec_author/page/1/nec_author.html"><img alt='Phil Martinez' class='avatar avatar-70 photo' height='70' src='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=70&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=140&#038;d=mm&#038;r=g 2x' width='70'></a>
<div class="text"><span>By <a href="author/nec_author/page/1/nec_author.html" rel="author">Phil Martinez</a></span> <span>In</span> <a class="fashion" href="category/fashion/fashion.html"><span class="fashion">Fashion</span></a></div>
</div>
<h2 class="post-ref-1"><a class="full-slide-link" href="doing-a-cross-country-road-trip.html">Doing a cross country road trip</a></h2>
<div class="excerpt">Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named&hellip;</div>
<a class="nectar-button large regular m-extra-color-gradient-2 has-icon" data-color-override="false" data-hover-color-override="false" data-hover-text-color-override="#fff" href="doing-a-cross-country-road-trip.html"><span>Read More</span> <i class="icon-button-arrow"></i></a></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>





<div class="wpb_row vc_row-fluid vc_row full-width-section" data-column-margin="default" data-midnight="dark" id="fws_6165491852c0b" style="padding-top: 0px; padding-bottom: 0px;">
<div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="false">
<div class="inner-wrap">
<div class="row-bg using-bg-color" style="background-color: #0a0a0a;"></div>
</div>
</div>
<div class="row_col_wrap_12 col span_12 dark left">
<div class="vc_col-sm-12 wpb_column column_container vc_column_container col neg-marg no-extra-padding" data-animation="" data-bg-color="" data-bg-opacity="1" data-delay="0" data-has-bg-color="false" data-padding-pos="all" style="margin-top: -5%;">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="row">
<div class="post-area col span_12 col_last masonry auto_meta_overlaid_spaced" data-ams="4px" data-remove-post-author="" data-remove-post-comment-number="" data-remove-post-date="" data-remove-post-nectar-love="">
<div class="posts-container" data-load-animation="none">
<article class=" masonry-blog-item post-219 post type-post status-publish format-standard has-post-thumbnail category-food-for-thought category-music" id="post-219">
<div class="inner-wrap animated">
<div class="post-content">
<div class="content-inner"><a aria-label="We encountered a true paradise" class="entire-meta-link" href="we-encountered-a-true-paradise.html"></a> <span class="post-featured-img" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/scott-walsh-315682-800x667.jpg);"></span>
<div class="article-content-wrap"><span class="meta-category"><a class="food-for-thought" href="category/food-for-thought/food-for-thought.html">Food for thought</a><a class="music" href="category/music/music.html">Music</a></span>
<div class="post-header">
<h3 class="title"><a href="we-encountered-a-true-paradise.html">We encountered a true paradise</a></h3>
</div>
</div>
<!--article-content-wrap--></div>
<!--/content-inner--></div>
<!--/post-content--></div>
<!--/inner-wrap--></article>
<article class=" masonry-blog-item post-222 post type-post status-publish format-video has-post-thumbnail category-food-for-thought tag-art tag-awesome tag-cars tag-classic tag-epic tag-funny tag-gaming-tips tag-music tag-photography tag-standard tag-videos post_format-post-format-video" id="post-222">
<div class="inner-wrap animated">
<div class="post-content">
<div class="content-inner"><span class="play"><span class="inner-wrap"><svg aria-hidden="true" height="800px" version="1.1" viewbox="0 0 600 800" width="600px" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
<path d="M0-1.79v800L600,395L0-1.79z" fill="none"></path>
</svg></span></span> <a aria-label="Deep down in the water" class="entire-meta-link" href="deep-down-in-the-water.html"></a> <span class="post-featured-img" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/03/steven-pahel-354193-800x800.jpg);"></span>
<div class="article-content-wrap"><span class="meta-category"><a class="food-for-thought" href="category/food-for-thought/food-for-thought.html">Food for thought</a></span>
<div class="post-header">
<h3 class="title"><a href="deep-down-in-the-water.html">Deep down in the water</a></h3>
</div>
</div>
<!--article-content-wrap--></div>
<!--/content-inner--></div>
<!--/post-content--></div>
<!--/inner-wrap--></article>
<article class=" masonry-blog-item post-2328 post type-post status-publish format-standard has-post-thumbnail category-fashion category-gaming tag-art tag-cars tag-funny tag-gaming-tips tag-standard tag-videos" id="post-2328">
<div class="inner-wrap animated">
<div class="post-content">
<div class="content-inner"><a aria-label="10 Tips for what to do downtown" class="entire-meta-link" href="10-tips-for-what-to-do-downtown.html"></a> <span class="post-featured-img" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/10/alesia-kazantceva-283291-800x667.jpg);"></span>
<div class="article-content-wrap"><span class="meta-category"><a class="fashion" href="category/fashion/fashion.html">Fashion</a><a class="gaming" href="category/gaming/gaming.html">Gaming</a></span>
<div class="post-header">
<h3 class="title"><a href="10-tips-for-what-to-do-downtown.html">10 Tips for what to do downtown</a></h3>
</div>
</div>
<!--article-content-wrap--></div>
<!--/content-inner--></div>
<!--/post-content--></div>
<!--/inner-wrap--></article>
<article class=" masonry-blog-item post-5618 post type-post status-publish format-standard has-post-thumbnail category-food-for-thought tag-awesome tag-epic tag-music tag-photography" id="post-5618">
<div class="inner-wrap animated">
<div class="post-content">
<div class="content-inner"><a aria-label="We hired a new employee" class="entire-meta-link" href="we-hired-a-new-employee.html"></a> <span class="post-featured-img" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/02/diana-macesanu-276771-800x601.jpg);"></span>
<div class="article-content-wrap"><span class="meta-category"><a class="food-for-thought" href="category/food-for-thought/food-for-thought.html">Food for thought</a></span>
<div class="post-header">
<h3 class="title"><a href="we-hired-a-new-employee.html">We hired a new employee</a></h3>
</div>
</div>
<!--article-content-wrap--></div>
<!--/content-inner--></div>
<!--/post-content--></div>
<!--/inner-wrap--></article>
<article class=" masonry-blog-item post-2327 post type-post status-publish format-standard has-post-thumbnail category-food-for-thought tag-art tag-awesome tag-gaming-tips" id="post-2327">
<div class="inner-wrap animated">
<div class="post-content">
<div class="content-inner"><a aria-label="Ambrose Redmoon" class="entire-meta-link" href="ambrose-redmoon.html"></a> <span class="post-featured-img" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/02/kimon-maritz-181128-800x800.jpg);"></span>
<div class="article-content-wrap"><span class="meta-category"><a class="food-for-thought" href="category/food-for-thought/food-for-thought.html">Food for thought</a></span>
<div class="post-header">
<h3 class="title"><a href="ambrose-redmoon.html">Ambrose Redmoon</a></h3>
</div>
</div>
<!--article-content-wrap--></div>
<!--/content-inner--></div>
<!--/post-content--></div>
<!--/inner-wrap--></article>
<article class=" masonry-blog-item post-2677 post type-post status-publish format-standard has-post-thumbnail category-fashion category-music tag-art tag-classic tag-epic tag-gaming-tips tag-videos" id="post-2677">
<div class="inner-wrap animated">
<div class="post-content">
<div class="content-inner"><a aria-label="Be My Guest Concert" class="entire-meta-link" href="be-my-guest-concert.html"></a> <span class="post-featured-img" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2014/07/austin-neill-247047-1-800x800.jpg);"></span>
<div class="article-content-wrap"><span class="meta-category"><a class="fashion" href="category/fashion/fashion.html">Fashion</a><a class="music" href="category/music/music.html">Music</a></span>
<div class="post-header">
<h3 class="title"><a href="be-my-guest-concert.html">Be My Guest Concert</a></h3>
</div>
</div>
<!--article-content-wrap--></div>
<!--/content-inner--></div>
<!--/post-content--></div>
<!--/inner-wrap--></article>
</div>
<!--/posts container--></div>
<!--/post area--></div>
</div>
</div>
</div>
</div>
</div>




<div class="wpb_row vc_row-fluid vc_row full-width-section vc_row-o-equal-height vc_row-flex vc_row-o-content-middle" data-column-margin="default" data-midnight="light" id="fws_616549185c50c" style="padding-top: 60px; padding-bottom: 60px;">
<div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="false">
<div class="inner-wrap">
<div class="row-bg using-bg-color" style="background-color: #0a0a0a;"></div>
</div>
</div>
<div class="row_col_wrap_12 col span_12 light left">
<div class="vc_col-sm-12 wpb_column column_container vc_column_container col force-tablet-text-align-center force-phone-text-align-center no-extra-padding" data-animation="" data-bg-color="" data-bg-opacity="1" data-delay="0" data-has-bg-color="false" data-padding-pos="all">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="nectar-cta" data-alignment="center" data-color="" data-display="block" data-style="see-through" data-text-color="std" data-using-bg="false">
<h5><span class="text"></span><span class="link_wrap"><a class="link_text" href="blog-dark-all-posts.html">View All Posts<span class="arrow"></span></a></span></h5>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="wpb_row vc_row-fluid vc_row full-width-section" data-bottom-percent="3%" data-column-margin="default" data-midnight="light" data-top-percent="4%" id="fws_616549185fefb" style="padding-top: calc(100vw * 0.04); padding-bottom: calc(100vw * 0.03);">
<div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="false">
<div class="inner-wrap">
<div class="row-bg using-bg-color" style="background-color: #0a0a0a;"></div>
</div>
</div>
<div class="row_col_wrap_12 col span_12 light left">
<div class="vc_col-sm-12 wpb_column column_container vc_column_container col no-extra-padding" data-animation="" data-bg-color="" data-bg-opacity="1" data-delay="0" data-has-bg-color="false" data-padding-pos="all">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="wpb_text_column wpb_content_element vc_custom_1504490629058">
<div class="wpb_wrapper">
<h2 style="text-align: center;">Latest In Travel Ideas</h2>
</div>
</div>
<div class="row blog-recent columns-2" data-color-scheme="light" data-remove-post-author="" data-remove-post-comment-number="" data-remove-post-date="" data-remove-post-nectar-love="" data-style="list_featured_first_row">
<div class="col span_6 post-2329 post type-post status-publish format-standard has-post-thumbnail category-fashion category-music tag-epic tag-music tag-standard"><a aria-label="Every day you learn something new" class="full-post-link" href="every-day-you-learn-something-new.html"></a><a aria-label="Every day you learn something new" class="featured" href="every-day-you-learn-something-new.html"><img alt="" class="attachment-portfolio-thumb size-portfolio-thumb wp-post-image" height="403" sizes="(max-width: 600px) 100vw, 600px" src="wp-content/uploads/2013/01/nadine-shaabana-291260-big-600x403.jpg" srcset="http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/01/nadine-shaabana-291260-big-600x403.jpg 600w, http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/01/nadine-shaabana-291260-big-400x269.jpg 400w" title="" width="600"></a>
<div class="post-header featured"><span class="meta-category"><a class="fashion" href="category/fashion/fashion.html">Fashion</a></span>
<h3>Every day you learn something new</h3>
</div>
<!--/post-header-->
<div class="excerpt">Cras et libero iaculis, consequat nisi nec, tristi que metus. Praesent eu odio in velit maximus accumsan</div>
</div>
<!--/col-->
<div class="col span_6 post-1239 post type-post status-publish format-standard has-post-thumbnail category-food-for-thought category-music"><a aria-label="Velit Porttito" class="full-post-link" href="velit-feugiat-porttito.html"></a><a aria-label="Velit Porttito" class="featured" href="velit-feugiat-porttito.html"><img alt="" class="attachment-portfolio-thumb size-portfolio-thumb wp-post-image" height="403" sizes="(max-width: 600px) 100vw, 600px" src="wp-content/uploads/2017/09/matheus-ferrero-228716-600x403.jpg" srcset="http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/matheus-ferrero-228716-600x403.jpg 600w, http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/matheus-ferrero-228716-400x269.jpg 400w" title="" width="600"></a>
<div class="post-header featured"><span class="meta-category"><a class="food-for-thought" href="category/food-for-thought/food-for-thought.html">Food for thought</a></span>
<h3>Velit Porttito</h3>
</div>
<!--/post-header-->
<div class="excerpt">Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place&hellip;</div>
</div>
<!--/col--></div>
<!--/blog-recent--></div>
</div>
</div>
</div>
</div>
<div class="wpb_row vc_row-fluid vc_row full-width-section vc_row-o-equal-height vc_row-flex vc_row-o-content-middle parallax_section" data-bottom-percent="15%" data-column-margin="default" data-midnight="light" data-top-percent="15%" id="fws_6165491866b63" style="padding-top: calc(100vw * 0.15); padding-bottom: calc(100vw * 0.15);">
<div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="true">
<div class="inner-wrap using-image">
<div class="row-bg using-image using-bg-color" data-parallax-speed="fast" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/footer-2.jpg); background-position: center bottom; background-repeat: no-repeat; background-color: #0a0a0a;"></div>
</div>
<div class="row-bg-overlay" style="background: #0a0a0a; background: linear-gradient(to bottom,#0a0a0a 0%,rgba(17,17,17,0.31) 100%); opacity: 1;"></div>
</div>
<div class="row_col_wrap_12 col span_12 light left">
<div class="vc_col-sm-12 wpb_column column_container vc_column_container col no-extra-padding" data-animation="" data-bg-color="" data-bg-opacity="1" data-delay="0" data-has-bg-color="false" data-padding-pos="all">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="wpb_row vc_row-fluid vc_row inner_row" data-column-margin="default" data-midnight="" id="fws_6165491868df4" style="">
<div class="row-bg-wrap">
<div class="row-bg"></div>
</div>
<div class="row_col_wrap_12_inner col span_12 left">
<div class="vc_col-sm-2 wpb_column column_container vc_column_container col child_column no-extra-padding" data-animation="" data-bg-color="" data-bg-opacity="1" data-delay="0" data-has-bg-color="false" data-padding-pos="all">
<div class="vc_column-inner">
<div class="wpb_wrapper"></div>
</div>
</div>
<div class="vc_col-sm-8 wpb_column column_container vc_column_container col child_column centered-text padding-2-percent" data-animation="" data-bg-color="" data-bg-opacity="1" data-delay="0" data-has-bg-color="false" data-padding-pos="left-right">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<h2 class="vc_custom_heading wpb_animate_when_almost_visible wpb_fadeInUp fadeInUp" style="font-size: 52px;line-height: 52px;text-align: center">Let's Start This Party</h2>
<div class="divider-wrap" data-alignment="default">
<div class="divider" style="height: 10px;"></div>
</div>
<p class="vc_custom_heading wpb_animate_when_almost_visible wpb_fadeInUp fadeInUp vc_custom_1504487727704" style="color: rgba(255,255,255,0.7);text-align: center">Like Nothing You've Seen. Purchase Today &amp; Experience Salient</p>
<a class="nectar-button jumbo regular m-extra-color-gradient-2 has-icon wpb_animate_when_almost_visible wpb_zoomIn zoomIn" data-color-override="false" data-hover-color-override="false" data-hover-text-color-override="#fff" href="https://themeforest.net/item/salient-responsive-multipurpose-theme/4363266" style=""><span>Learn More</span><i class="icon-button-arrow"></i></a></div>
</div>
</div>
<div class="vc_col-sm-2 wpb_column column_container vc_column_container col child_column no-extra-padding" data-animation="" data-bg-color="" data-bg-opacity="1" data-delay="0" data-has-bg-color="false" data-padding-pos="all">
<div class="vc_column-inner">
<div class="wpb_wrapper"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php get_footer(); ?>