<div data-bg-img-overlay="0.8" data-cols="1" data-copyright-line="false" data-custom-color="true" data-disable-copyright="false" data-full-width="false" data-link-hover="default" data-matching-section-color="true" data-using-bg-img="false" data-using-widget-area="false" id="footer-outer">
<div class="row" data-layout="default" id="copyright">
<div class="container">
<div class="col span_7 col_last">
<ul class="social">
<li><a href="../salient-blog-dark.html" target="_blank"><span class="screen-reader-text">twitter</span><i aria-hidden="true" class="fab fa-twitter"></i></a></li>
<li><a href="../salient-blog-dark.html" target="_blank"><span class="screen-reader-text">facebook</span><i aria-hidden="true" class="fab fa-facebook-f"></i></a></li>
<li><a href="../salient-blog-dark.html" target="_blank"><span class="screen-reader-text">google-plus</span><i aria-hidden="true" class="fab fa-google"></i></a></li>
<li><a href="../salient-blog-dark.html" target="_blank"><span class="screen-reader-text">yelp</span><i aria-hidden="true" class="fa fa-yelp"></i></a></li>
</ul>
</div>
<!--/span_7-->
<div class="col span_5">
<div class="widget"></div>
<p>&copy; 2021 Salient Blog Dark.</p>
</div>
<!--/span_5--></div>
<!--/container--></div>
<!--/row--></div>
<!--/footer-outer-->
<div class="slide-out-from-right dark" id="slide-out-widget-area-bg"></div>
<div class="slide-out-from-right" data-back-txt="Back" data-dropdown-func="separate-dropdown-parent-link" id="slide-out-widget-area">
<div class="inner-wrap">
<div class="inner" data-prepend-menu-mobile="false"><a class="slide_out_area_close" href="../salient-blog-dark.html#"><span class="screen-reader-text">Close Menu</span> <span class="close-wrap"><span class="close-line close-line1"></span> <span class="close-line close-line2"></span></span></a>
<div class="widget widget_text" id="text-3">
<h4>Wow look at this!</h4>
<div class="textwidget">
<p>This is an optional, highly<br>
customizable off canvas area.</p>
</div>
</div>
<div class="widget widget_text" id="text-2">
<div class="textwidget">
<div class="widget widget_text" id="text-2"></div>
<div class="widget widget_text" id="text-4">
<div class="textwidget">
<h4>About Salient</h4>
<div class="textwidget">
<p>The Castle<br>
Unit 345<br>
2500 Castle Dr<br>
Manhattan, NY</p>
<p>T:&nbsp;<a href="../salient-ascend.html#">+216 (0)40 3629 4753</a><br>
E:&nbsp;<a href="../salient-ascend.html#">hello@themenectar.com</a></p>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="bottom-meta-wrap">
<ul class="off-canvas-social-links"></ul>
</div>
<!--/bottom-meta-wrap--></div>
<!--/inner-wrap--></div>
</div>
<!--/ajax-content-wrap-->
<a class=" mobile-enabled" id="to-top"><i class="fa fa-angle-up"></i></a></div>
</div>
<!--/ocm-effect-wrap-->









<script id="wpb-modifications" type="text/html">
</script>


<!-- CSS -->
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/animate.min.css' id='vc_animate-css-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/magnific.css' id='magnific-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/core.css' id='nectar-ocm-core-css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/slide-out-right-material.css' id='nectar-ocm-slide-out-right-material-css' media='all' rel='stylesheet' type='text/css'>


<script id='salient-social-js-extra' type='text/javascript'>
/* <![CDATA[ */
var nectarLove = {"ajaxurl":"http:\/\/themenectar.com\/demo\/salient-blog-dark\/wp-admin\/admin-ajax.php","postID":"5765","rooturl":"http:\/\/themenectar.com\/demo\/salient-blog-dark","loveNonce":"c68079da90"};
/* ]]> */
</script>


<script id='salient-social-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/salient-social.js' type='text/javascript'>
</script> 
<script id='jquery-easing-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/jquery.easing.js' type='text/javascript'>
</script> 
<script id='jquery-mousewheel-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/jquery.mousewheel.js' type='text/javascript'>
</script> 
<script id='nectar_priority-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/priority.js' type='text/javascript'>
</script> 
<script id='nectar-transit-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/transit.js' type='text/javascript'>
</script> 
<script id='nectar-waypoints-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/waypoints.js' type='text/javascript'>
</script> 
<script id='imagesLoaded-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/imagesLoaded.min.js' type='text/javascript'>
</script> 
<script id='hoverintent-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/hoverintent.js' type='text/javascript'>
</script> 
<script id='magnific-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/magnific.js' type='text/javascript'>
</script> 
<script id='superfish-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/superfish.js' type='text/javascript'>
</script> 
<script id='nectar-frontend-js-extra' type='text/javascript'>
/* <![CDATA[ */
var nectarLove = {"ajaxurl":"http:\/\/themenectar.com\/demo\/salient-blog-dark\/wp-admin\/admin-ajax.php","postID":"5765","rooturl":"http:\/\/themenectar.com\/demo\/salient-blog-dark","disqusComments":"false","loveNonce":"c68079da90","mapApiKey":""};
var nectarOptions = {"quick_search":"false","mobile_header_format":"default","left_header_dropdown_func":"default","ajax_add_to_cart":"0","ocm_remove_ext_menu_items":"remove_images","woo_product_filter_toggle":"0","woo_sidebar_toggles":"true","woo_sticky_sidebar":"0","woo_minimal_product_hover":"default","woo_minimal_product_effect":"default","woo_related_upsell_carousel":"false","woo_product_variable_select":"default"};
var nectar_front_i18n = {"next":"Next","previous":"Previous"};
/* ]]> */
</script> 
<script id='nectar-frontend-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/init.js' type='text/javascript'>
</script> 
<script id='flexslider-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/jquery.flexslider.min.js' type='text/javascript'>
</script> 
<script id='isotope-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/isotope.min.js' type='text/javascript'>
</script> 
<script id='nectar-masonry-blog-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/nectar-blog.js' type='text/javascript'>
</script> 
<script id='touchswipe-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/touchswipe.min.js' type='text/javascript'>
</script> 
<script id='wp-embed-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/wp-embed.min.js' type='text/javascript'>
</script> 
<script id='wpb_composer_front_js-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/js_composer_front.min.js' type='text/javascript'>
</script><!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/

Minified using disk

Served from: themenectar.com @ 2021-10-12 08:36:40 by W3 Total Cache
-->
</body>
</html>