<?php
/**
 * The template for displaying the header
 * 
 * displays all of the head element and everything up until the "site-content" div.
 * 
 * @package WordPress
 * @subpackage webdesign
 * @since webdesign 1.0
 */
get_header(); ?>

<?php get_footer(); ?>