<?php
/**
/* Template Name: we-encountered-a-true-paradise
 *
 * Displays Only we-encountered-a-true-paradise template
 *
 * @package WordPress
 * @subpackage webdesign
 * @since webdesign 1.0
 */
 get_header(); ?>
<div id="ajax-content-wrap">
<div id="page-header-wrap" data-animate-in-effect="zoom-out" data-midnight="light" class="" style="height: 550px;"><div id="page-header-bg" class="not-loaded  hentry" data-post-hs="default_minimal" data-padding-amt="normal" data-animate-in-effect="zoom-out" data-midnight="light" data-text-effect="" data-bg-pos="center" data-alignment="left" data-alignment-v="middle" data-parallax="1" data-height="550"  style="height:550px;">					<div class="page-header-bg-image-wrap" id="nectar-page-header-p-wrap" data-parallax-speed="fast">
						<div class="page-header-bg-image" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/footer-2.jpg);"></div>
					</div> 
				<div class="container"><img class="hidden-social-img" src="../wp-content/uploads/2017/09/footer-2.jpg" alt="We encountered a true paradise" />
					<div class="row">
						<div class="col span_6 section-title blog-title" data-remove-post-date="0" data-remove-post-author="0" data-remove-post-comment-number="0">
							<div class="inner-wrap">

								<a class="food-for-thought" href="../category/food-for-thought/food-for-thought.html" >Food for thought</a><a class="music" href="../category/music/music.html" >Music</a>
								<h1 class="entry-title">We encountered a true paradise</h1>

								

																	<div id="single-below-header" data-hide-on-mobile="false">
										<span class="meta-author vcard author"><span class="fn"><span class="author-leading">By</span> <a href="../author/nec_author/page/1/nec_author.html" title="Posts by Phil Martinez" rel="author">Phil Martinez</a></span></span><span class="meta-date date published">April 21, 2013</span><span class="meta-date date updated rich-snippet-hidden">October 2nd, 2017</span><span class="meta-comment-count"><a href="../we-encountered-a-true-paradise.html#respond">No Comments</a></span>									</div><!--/single-below-header-->
						
											</div>

				</div><!--/section-title-->
			</div><!--/row-->

			


			</div>
</div>

</div>

<div class="container-wrap no-sidebar" data-midnight="dark" data-remove-post-date="0" data-remove-post-author="0" data-remove-post-comment-number="0">
	<div class="container main-content">

		
		<div class="row">

			
			<div class="post-area col  span_12 col_last">

			
<article id="post-219" class="post-219 post type-post status-publish format-standard has-post-thumbnail category-food-for-thought category-music">
  
  <div class="inner-wrap">

		<div class="post-content" data-hide-featured-media="1">
      
        <div class="content-inner">
		<div id="fws_6165486212818"  data-column-margin="default" data-midnight="dark"  class="wpb_row vc_row-fluid vc_row  "  style="padding-top: 0px; padding-bottom: 0px; "><div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="false"><div class="inner-wrap"><div class="row-bg"  style=""></div></div></div><div class="row_col_wrap_12 col span_12 dark left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col no-extra-padding"  data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
			<div class="wpb_wrapper">
				
<div class="wpb_text_column wpb_content_element " >
	<div class="wpb_wrapper">
		<h4>Even the all-powerful Pointing has no control</h4>
<p>far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
	</div>
</div>




			</div> 
		</div>
	</div> 
</div></div>
		<div id="fws_6165486213952"  data-column-margin="default" data-midnight="dark"  class="wpb_row vc_row-fluid vc_row  "  style="padding-top: 0px; padding-bottom: 40px; "><div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="false"><div class="inner-wrap"><div class="row-bg"  style=""></div></div></div><div class="row_col_wrap_12 col span_12 dark left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col no-extra-padding"  data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
			<div class="wpb_wrapper">
				
<div class="wpb_text_column wpb_content_element " >
	<div class="wpb_wrapper">
		<p>far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
	</div>
</div>




			</div> 
		</div>
	</div> 
</div></div>
		<div id="fws_6165486214d1c"  data-column-margin="default" data-midnight="dark" data-top-percent="5%" data-bottom-percent="5%"  class="wpb_row vc_row-fluid vc_row parallax_section "  style="padding-top: calc(100vw * 0.05); padding-bottom: calc(100vw * 0.05); "><div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="false"><div class="inner-wrap using-image"><div class="row-bg using-image" data-parallax-speed="fast" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/scott-walsh-315682.jpg); background-position: center center; background-repeat: no-repeat; "></div></div></div><div class="row_col_wrap_12 col span_12 dark left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col no-extra-padding"  data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
			<div class="wpb_wrapper">
				<div class="divider-wrap" data-alignment="default"><div style="height: 300px;" class="divider"></div></div>
			</div> 
		</div>
	</div> 
</div></div>
		<div id="fws_6165486215b36"  data-column-margin="default" data-midnight="dark"  class="wpb_row vc_row-fluid vc_row  "  style="padding-top: 40px; padding-bottom: 0px; "><div class="row-bg-wrap" data-bg-animation="none" data-bg-overlay="false"><div class="inner-wrap"><div class="row-bg"  style=""></div></div></div><div class="row_col_wrap_12 col span_12 dark left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col no-extra-padding"  data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
			<div class="wpb_wrapper">
				
<div class="wpb_text_column wpb_content_element " >
	<div class="wpb_wrapper">
		<h4>The Big Oxmox</h4>
<p>advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn’t listen. She packed her seven versalia, put her initial into the belt and made herself on the way.  Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p>
<p>far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
	</div>
</div>




			</div> 
		</div>
	</div> 
</div></div>
</div>        
      </div><!--/post-content-->
      
    </div><!--/inner-wrap-->
    
</article>
<div id="author-bio" class="" data-has-tags="false">

	<div class="span_12">

	<img alt='Phil Martinez' src='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=80&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=160&#038;d=mm&#038;r=g 2x' class='avatar avatar-80 photo' height='80' width='80' loading='lazy'/>	<div id="author-info">

	  <h3><span></span>

		<a href="../author/nec_author/page/1/nec_author.html">Phil Martinez</a>		</h3>
	  <p>WordPress Theme Developer</p>

	</div>

	
	<div class="clear"></div>

	</div><!--/span_12-->

</div><!--/author-bio-->

		</div><!--/post-area-->

			
		</div><!--/row-->

		<div class="row">

			
			 <div data-post-header-style="default_minimal" class="blog_next_prev_buttons wpb_row vc_row-fluid full-width-content standard_section" data-style="fullwidth_next_prev" data-midnight="light">

				 <ul class="controls"><li class="previous-post "><div class="post-bg-img" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2014/07/rob-bates-306647-1.jpg);"></div><a href="../doing-a-cross-country-road-trip.html"></a><h3><span>Previous Post</span><span class="text">Doing a cross country road trip
						 <svg class="next-arrow" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 39 12"><line class="top" x1="23" y1="-0.5" x2="29.5" y2="6.5" stroke="#ffffff;"></line><line class="bottom" x1="23" y1="12.5" x2="29.5" y2="5.5" stroke="#ffffff;"></line></svg><span class="line"></span></span></h3></li><li class="next-post "><div class="post-bg-img" style="background-image: url(http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/alberto-restifo-4508.jpg);"></div><a href="../deep-down-in-the-water.html"></a><h3><span>Next Post</span><span class="text">Deep down in the water
						 <svg class="next-arrow" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 39 12"><line class="top" x1="23" y1="-0.5" x2="29.5" y2="6.5" stroke="#ffffff;"></line><line class="bottom" x1="23" y1="12.5" x2="29.5" y2="5.5" stroke="#ffffff;"></line></svg><span class="line"></span></span></h3></li></ul>
			 </div>

			 <div class="row vc_row-fluid full-width-section related-post-wrap" data-using-post-pagination="true" data-midnight="dark"> <div class="row-bg-wrap"><div class="row-bg"></div></div> <h3 class="related-title ">Recommended For You</h3><div class="row span_12 blog-recent related-posts columns-3" data-style="material" data-color-scheme="light">
					 <div class="col span_4">
						 <div class="inner-wrap post-222 post type-post status-publish format-video has-post-thumbnail category-food-for-thought tag-art tag-awesome tag-cars tag-classic tag-epic tag-funny tag-gaming-tips tag-music tag-photography tag-standard tag-videos post_format-post-format-video">

							 <a href="../deep-down-in-the-water.html" class="img-link"><span class="post-featured-img"><img width="600" height="403" src="../wp-content/uploads/2013/03/steven-pahel-354193-600x403.jpg" class="attachment-portfolio-thumb size-portfolio-thumb wp-post-image" alt="" loading="lazy" title="" srcset="http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/03/steven-pahel-354193-600x403.jpg 600w, http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/03/steven-pahel-354193-400x269.jpg 400w" sizes="(max-width: 600px) 100vw, 600px" /></span></a>
							 <span class="meta-category"><a class="food-for-thought" href="../category/food-for-thought/food-for-thought.html">Food for thought</a></span>
							 <a class="entire-meta-link" href="../deep-down-in-the-water.html"></a>

							 <div class="article-content-wrap">
								 <div class="post-header">
									 <span class="meta">
										 									 </span>
									 <h3 class="title">Deep down in the water</h3>
									 								 </div><!--/post-header-->

								 <div class="grav-wrap"><img alt='Phil Martinez' src='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=70&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=140&#038;d=mm&#038;r=g 2x' class='avatar avatar-70 photo' height='70' width='70' loading='lazy'/><div class="text"> <a href="../author/nec_author/page/1/nec_author.html">Phil Martinez</a><span>March 23, 2013</span></div></div>							 </div>

							 
						 </div>
					 </div>
					 
					 <div class="col span_4">
						 <div class="inner-wrap post-5618 post type-post status-publish format-standard has-post-thumbnail category-food-for-thought tag-awesome tag-epic tag-music tag-photography">

							 <a href="../we-hired-a-new-employee.html" class="img-link"><span class="post-featured-img"><img width="600" height="403" src="../wp-content/uploads/2013/02/diana-macesanu-276771-600x403.jpg" class="attachment-portfolio-thumb size-portfolio-thumb wp-post-image" alt="" loading="lazy" title="" srcset="http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/02/diana-macesanu-276771-600x403.jpg 600w, http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/02/diana-macesanu-276771-400x269.jpg 400w" sizes="(max-width: 600px) 100vw, 600px" /></span></a>
							 <span class="meta-category"><a class="food-for-thought" href="../category/food-for-thought/food-for-thought.html">Food for thought</a></span>
							 <a class="entire-meta-link" href="../we-hired-a-new-employee.html"></a>

							 <div class="article-content-wrap">
								 <div class="post-header">
									 <span class="meta">
										 									 </span>
									 <h3 class="title">We hired a new employee</h3>
									 								 </div><!--/post-header-->

								 <div class="grav-wrap"><img alt='Phil Martinez' src='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=70&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=140&#038;d=mm&#038;r=g 2x' class='avatar avatar-70 photo' height='70' width='70' loading='lazy'/><div class="text"> <a href="../author/nec_author/page/1/nec_author.html">Phil Martinez</a><span>February 22, 2013</span></div></div>							 </div>

							 
						 </div>
					 </div>
					 
					 <div class="col span_4">
						 <div class="inner-wrap post-2327 post type-post status-publish format-standard has-post-thumbnail category-food-for-thought tag-art tag-awesome tag-gaming-tips">

							 <a href="../ambrose-redmoon.html" class="img-link"><span class="post-featured-img"><img width="600" height="403" src="../wp-content/uploads/2013/02/kimon-maritz-181128-600x403.jpg" class="attachment-portfolio-thumb size-portfolio-thumb wp-post-image" alt="" loading="lazy" title="" srcset="http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/02/kimon-maritz-181128-600x403.jpg 600w, http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2013/02/kimon-maritz-181128-400x269.jpg 400w" sizes="(max-width: 600px) 100vw, 600px" /></span></a>
							 <span class="meta-category"><a class="food-for-thought" href="../category/food-for-thought/food-for-thought.html">Food for thought</a></span>
							 <a class="entire-meta-link" href="../ambrose-redmoon.html"></a>

							 <div class="article-content-wrap">
								 <div class="post-header">
									 <span class="meta">
										 									 </span>
									 <h3 class="title">Ambrose Redmoon</h3>
									 								 </div><!--/post-header-->

								 <div class="grav-wrap"><img alt='Phil Martinez' src='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=70&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/3d7188c8a0ece7220484b68f722da404?s=140&#038;d=mm&#038;r=g 2x' class='avatar avatar-70 photo' height='70' width='70' loading='lazy'/><div class="text"> <a href="../author/nec_author/page/1/nec_author.html">Phil Martinez</a><span>February 15, 2013</span></div></div>							 </div>

							 
						 </div>
					 </div>
					 </div></div>
			<div class="comments-section" data-author-bio="true">
				
<div class="comment-wrap " data-midnight="dark" data-comments-open="true">


			<!-- If comments are open, but there are no comments. -->

	 

	<div id="respond" class="comment-respond">
		<h3 id="reply-title" class="comment-reply-title">Leave a Reply <small><a rel="nofollow" id="cancel-comment-reply-link" href="../we-encountered-a-true-paradise.html#respond" style="display:none;">Cancel Reply</a></small></h3><form action="http://themenectar.com/demo/salient-blog-dark/wp-comments-post.php" method="post" id="commentform" class="comment-form"><div class="row"><div class="col span_12"><label for="comment">My comment is..</label><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></div></div><div class="row"> <div class="col span_4"><label for="author">Name <span class="required">*</span></label> <input id="author" name="author" type="text" value="" size="30" /></div>
<div class="col span_4"><label for="email">Email <span class="required">*</span></label><input id="email" name="email" type="text" value="" size="30" /></div>
<div class="col span_4 col_last"><label for="url">Website</label><input id="url" name="url" type="text" value="" size="30" /></div></div>
<p class="comment-form-cookies-consent"><input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes" /><label for="wp-comment-cookies-consent">Save my name, email, and website in this browser for the next time I comment.</label></p>
<p class="form-submit"><input name="submit" type="submit" id="submit" class="submit" value="Submit Comment" /> <input type='hidden' name='comment_post_ID' value='219' id='comment_post_ID' />
<input type='hidden' name='comment_parent' id='comment_parent' value='0' />
</p></form>	</div><!-- #respond -->
	
</div>			</div>

		</div><!--/row-->

	</div><!--/container main-content-->
	</div><!--/container-wrap-->

<div class="nectar-social fixed" data-position="" data-rm-love="0" data-color-override="override"><a href="../we-encountered-a-true-paradise.html#"><i class="icon-default-style steadysets-icon-share"></i></a><div class="nectar-social-inner"><a class='facebook-share nectar-sharing' href='../we-encountered-a-true-paradise.html#' title='Share this'> <i class='fa fa-facebook'></i> <span class='social-text'>Share</span> </a><a class='twitter-share nectar-sharing' href='../we-encountered-a-true-paradise.html#' title='Tweet this'> <i class='fa fa-twitter'></i> <span class='social-text'>Tweet</span> </a><a class='linkedin-share nectar-sharing' href='../we-encountered-a-true-paradise.html#' title='Share this'> <i class='fa fa-linkedin'></i> <span class='social-text'>Share</span> </a><a class='pinterest-share nectar-sharing' href='../we-encountered-a-true-paradise.html#' title='Pin this'> <i class='fa fa-pinterest'></i> <span class='social-text'>Pin</span> </a></div></div>
<?php get_footer(); ?>