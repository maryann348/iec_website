<!DOCTYPE html>
<html class="no-js" lang="en-US">
<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" name="viewport">
<meta content='noindex, nofollow' name='robots'>
<meta content="WordPress 5.7.3" name="generator">
<meta content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." name="generator">
<title>Salient Blog Dark &#8211; The Ultimate WordPress Theme</title>
<!-- Fonts -->
<link href='http://fonts.googleapis.com/' rel='dns-prefetch'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700&#038;subset=latin%2Clatin-ext' id='nectar_default_font_open_sans-css' media='all' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto%3A500%2C700%7CNunito%3A300%2C700%2C400%2C400italic%7CMuli%3A600%7CPlayfair+Display%3A400%7CMontserrat%3A500&#038;subset=latin&#038;ver=1616442046' id='redux-google-fonts-salient_redux-css' media='all' rel='stylesheet' type='text/css'>

<!-- CSS -->
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/custom.css" media='all' rel="stylesheet" type="text/css">
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/social.css' media='all' rel='stylesheet' type='text/css'>

<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/grid-system.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/style.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/header-layout-centered-logo-between-menu.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/element-recent-posts.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/masonry-meta-overlaid.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/auto-masonry-meta-overlaid-spaced.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/responsive.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/skin-material.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/menu-dynamic.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/widget-nectar-posts.css' media='all' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/css/js_composer.min.css' media='all' rel='stylesheet' type='text/css'>


<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/icon/css/all.css" rel="stylesheet" media="all">


<!-- JSON -->
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/json/wp-json.json" rel="https://api.w.org/">
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/json/5765.json" rel="alternate" type="application/json">
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/json/embed.json" rel="alternate" type="application/json+oembed">
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/json/embed.xml" rel="alternate" type="text/xml+oembed">


<!-- XML -->
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/xml/xmlrpc.xml" rel="EditURI" title="RSD" type="application/rsd+xml">
<link href="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/xml/wlwmanifest.xml" rel="wlwmanifest" type="application/wlwmanifest+xml"><!-- <link rel="canonical" href="../salient-blog-dark.html" />
<link rel='shortlink' href='../salient-blog-dark.html' />
<link rel="alternate" type="application/rss+xml" title="Salient Blog Dark &raquo; Feed" href="feed/feed.html" />
<link rel="alternate" type="application/rss+xml" title="Salient Blog Dark &raquo; Comments Feed" href="comments/feed/feed.html" /> -->

<script id='jquery-core-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/jquery.min.js' type='text/javascript'>
</script>
<script id='jquery-migrate-js' src='<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/js/jquery-migrate.min.js' type='text/javascript'>
</script>
<script type="text/javascript">
 
var root = document.getElementsByTagName( "html" )[0]; root.setAttribute( "class", "js" ); 
</script>
</head>
<body class="home page-template-default page page-id-5765 material wpb-js-composer js-comp-ver-6.6.0 vc_responsive" data-aie="zoom-out" data-ajax-transitions="true" data-animated-anchors="true" data-apte="standard" data-bg-header="true" data-body-border="off" data-boxed-style="" data-button-style="slightly_rounded_shadow" data-cad="700" data-cae="easeOutQuart" data-cart="false" data-col-gap="default" data-dropdown-style="minimal" data-ext-padding="90" data-ext-responsive="true" data-fancy-form-rcs="default" data-flex-cols="true" data-footer-reveal="1" data-footer-reveal-shadow="none" data-force-header-trans-color="light" data-form-style="minimal" data-form-submit="regular" data-full-width-header="false" data-header-breakpoint="1000" data-header-color="custom" data-header-format="centered-logo-between-menu" data-header-inherit-rc="false" data-header-resize="0" data-header-search="true" data-hhun="1" data-is="minimal" data-loading-animation="none" data-ls="magnific" data-m-animate="0" data-megamenu-width="full-width" data-permanent-transparent="false" data-remove-m-parallax="" data-remove-m-video-bgs="" data-responsive="1" data-slide-out-widget-area="true" data-slide-out-widget-area-style="slide-out-from-right" data-smooth-scrolling="0" data-user-account-button="false" data-user-set-ocm="1">
<script type="text/javascript">
     (function(window, document) {

         if(navigator.userAgent.match(/(Android|iPod|iPhone|iPad|BlackBerry|IEMobile|Opera Mini)/)) {
             document.body.className += " using-mobile-browser ";
         }

         if( !("ontouchstart" in window) ) {

             var body = document.querySelector("body");
             var winW = window.innerWidth;
             var bodyW = body.clientWidth;

             if (winW > bodyW + 4) {
                 body.setAttribute("style", "--scroll-bar-w: " + (winW - bodyW - 4) + "px");
             } else {
                 body.setAttribute("style", "--scroll-bar-w: 0px");
             }
         }

     })(window, document);
</script><a class="nectar-skip-to-content" href="../salient-blog-dark.html#ajax-content-wrap">Skip to main content</a>
<div class="ocm-effect-wrap">
<div class="ocm-effect-wrap-inner">
<div data-disable-fade-on-click="0" data-disable-mobile="1" data-effect="standard" data-method="standard" id="ajax-loading-screen">
<div class="loading-icon none">
<div class="material-icon">
<div class="spinner">
<div class="right-side">
<div class="bar"></div>
</div>
<div class="left-side">
<div class="bar"></div>
</div>
</div>
<div class="spinner color-2">
<div class="right-side">
<div class="bar"></div>
</div>
<div class="left-side">
<div class="bar"></div>
</div>
</div>
</div>
</div>
</div>
<div data-header-mobile-fixed='1' id="header-space"></div>
<div class="transparent" data-box-shadow="none" data-cart="false" data-condense="false" data-format="centered-logo-between-menu" data-full-width="false" data-has-buttons="yes" data-has-menu="false" data-header-button_style="default" data-header-resize="0" data-lhe="animated_underline" data-logo-height="24" data-m-logo-height="24" data-megamenu-rt="1" data-mobile-fixed="1" data-padding="36" data-permanent-transparent="false" data-ptnm="false" data-remove-border="true" data-remove-fixed="0" data-shrink-num="6" data-transparency-option="1" data-transparent-header="true" data-transparent-shadow-helper="false" data-user-set-bg="#0a0a0a" data-using-logo="1" data-using-pr-menu="false" data-using-secondary="0" id="header-outer">
<div class="nectar" id="search-outer">
<div id="search">
<div class="container">
<div id="search-box">
<div class="inner-wrap">
<div class="col span_12">
<form action="../salient-blog-dark.html" method="get" role="search"><input aria-label="Search" name="s" placeholder="Search" type="text" value=""> <span>Hit enter to search or ESC to close</span></form>
</div>
<!--/span_12--></div>
<!--/inner-wrap--></div>
<!--/search-box-->
<div id="close"><a href="../salient-blog-dark.html#"><span class="screen-reader-text">Close Search</span> <span class="close-wrap"><span class="close-line close-line1"></span> <span class="close-line close-line2"></span></span></a></div>
</div>
<!--/container--></div>
<!--/search--></div>
<!--/search-outer-->
<header id="top">
<div class="container">
<div class="row">
<div class="col span_3"><a data-supplied-ml="false" data-supplied-ml-starting="false" data-supplied-ml-starting-dark="false" href="http://themenectar.com/demo/salient-blog-dark" id="logo"><img alt="Salient Blog Dark" class="stnd skip-lazy default-logo dark-version" height="24" src="wp-content/uploads/2017/09/logo-robot-light.png" srcset="http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/logo-robot-light.png 1x, http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/logo-robot-light-retina.png 2x" width="105"><img alt="Salient Blog Dark" class="starting-logo skip-lazy default-logo" height="24" src="wp-content/uploads/2017/09/logo-robot-light.png" srcset="http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/logo-robot-light.png 1x, http://themenectar.com/demo/salient-blog-dark/wp-content/uploads/2017/09/logo-robot-light-retina.png 2x" width="105"></a></div>
<!--/span_3-->
<div class="col span_9 col_last"><a class="mobile-search" href="../salient-blog-dark.html#searchbox"><span aria-hidden="true" class="nectar-icon icon-salient-search"></span><span class="screen-reader-text">search</span></a>
<div class="slide-out-widget-area-toggle mobile-icon slide-out-from-right" data-custom-color="false" data-icon-animation="simple-transform">
<div><a aria-expanded="false" aria-label="Navigation Menu" class="closed" href="../salient-blog-dark.html#sidewidgetarea"><span class="screen-reader-text">Menu</span> <span aria-hidden="true"><i class="lines-button x2"><i class="lines"></i></i></span></a></div>
</div>
<nav>
<ul class="sf-menu">
<li class="no-menu-assigned"><a href="../salient-blog-dark.html#">No menu assigned</a></li>
<li class="button_social_group" id="social-in-menu"><a href="../salient-blog-dark.html" target="_blank"><span class="screen-reader-text">twitter</span><i aria-hidden="true" class="fab fa-twitter"></i></a> <a href="../salient-blog-dark.html" target="_blank"><span class="screen-reader-text">facebook</span><i aria-hidden="true" class="fab fa-facebook-f"></i></a> <a href="../salient-blog-dark.html" target="_blank"><span class="screen-reader-text">google-plus</span><i aria-hidden="true" class="fab fa-google"></i></a></li>
</ul>
<ul class="buttons sf-menu" data-user-set-ocm="1">
<li id="search-btn">
<div><a href="../salient-blog-dark.html#searchbox"><span aria-hidden="true" class="icon-salient-search"></span><span class="screen-reader-text">search</span></a></div>
</li>
<li class="slide-out-widget-area-toggle" data-custom-color="false" data-icon-animation="simple-transform">
<div><a aria-expanded="false" aria-label="Navigation Menu" class="closed" href="../salient-blog-dark.html#sidewidgetarea"><span class="screen-reader-text">Menu</span> <span aria-hidden="true"><i class="lines-button x2"><i class="lines"></i></i></span></a></div>
</li>
</ul>
</nav>
<div class="logo-spacing" data-using-image="true"><img alt="Salient Blog Dark" class="hidden-logo" height="24" src="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/uploads/2017/09/logo-robot-light.png" width="105"></div>
</div>
<!--/span_9--></div>
<!--/row--></div>
<!--/container--></header>
</div>